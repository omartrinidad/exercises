```
/*=========================================
# Group member (Name, Student ID, E-Mail) 
	- Omar Trinidad Gutierrez Mendez, 2850441, omar.vpa@gmail.com 
	- Shinho Kang, 2890169, wis.shinho.kang@gmail.com

# PA-A
    - To implement a 2-layer Perzeptron

# Instruction
    - Please read the "README.txt" file to compile and execute this source code.    
=========================================*/
```
** This file is written in Markdown syntax. **

1. To compile the source.
console command:
`cmake -G "Unix Makefiles" `
`make`

2. To run the program to read data file
`./perzeptron <data file name>`
e.g.
`./perzeptron PA-A-train.dat`

